#!/bin/bash
 
cd /home/edwin/eclipse-workspace/Quickstart gradle run

